package kr.or.ozz.dto;

public class MypageDTO {

}
