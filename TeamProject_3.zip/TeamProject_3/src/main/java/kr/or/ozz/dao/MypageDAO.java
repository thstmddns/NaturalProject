package kr.or.ozz.dao;

public interface MypageDAO {

}
